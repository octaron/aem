from autoemail import *

temp_password='12345'
destinatario='octaron82@gmail.com'
remitente='octaron82@gmail.com'
password='Qazxsw1836'
mensaje='Tu contraseña temporal es: '+temp_password
titulo='Restitución de contraseña AEM'

correo=Auto_email()
correo.enviar_correo(destinatario,remitente,password,mensaje,titulo)
