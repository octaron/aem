from modelos import *
import sqlite3
import datetime as dt
from datetime import datetime, timedelta
import pytz
from forms import *
from flask import Flask, render_template,url_for,redirect
from setupdatabase import Pase_lista




#nueva_renta=Rentas(1,1,'2018-09-23','09:23','10:25',1,'servicios')

#db.session.add(nueva_renta)
#db.session.commit()
salon='Grande'
fec_renta='2018-09-30'
hora_inicial='09:30:00'
hora_inicial=hora_inicial+':00.000000'
#hora_final='11:00'

#hi=datetime.strptime(hora_inicial,'%H:%M')
#h_inicial=dt.time(hi.hour,hi.minute,hi.second,hi.microsecond)
#print(type(h_inicial))
#print(h_inicial)

conexion=sqlite3.connect("data.sqlite")
cursor=conexion.cursor()

#cursor.execute("SELECT id FROM rentas WHERE salon='{}' AND fec_renta='{}' AND ((hora_inicial<='{}' AND hora_final>'{}') OR (hora_inicial<'{}' AND hora_final>='{}') OR (hora_inicial>'{}' AND hora_final<'{}'))".format(salon,fec_renta,hora_inicial,hora_inicial,hora_final,hora_final,hora_inicial,hora_final))
cursor.execute("SELECT id,hora_final FROM Rentas WHERE salon='{}' AND fec_renta='{}' AND hora_final>'{}'".format(salon,fec_renta,hora_inicial))
r=cursor.fetchall()
print(r)
print(type(r))
#print (nueva_renta)
print ('************************************************************************+')
l_omega=[1,2,3,4,5,6,7,8,9,10]
l_agregados=[2,3]
l_mat_disp=[]

for n in l_omega:
    if n not in l_agregados:
        l_mat_disp.append(n)
print (l_omega)
print (l_agregados)
print(l_mat_disp)
print ('Terminado')
