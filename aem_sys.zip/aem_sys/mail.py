import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib

# "Instanciando" el mensaje:
msg = MIMEMultipart()

mensaje = "¡Ya pude!"
destinatario="octaron82@gmail.com"
# Parámetros del mensaje
password = "Qazxsw1836"
msg['From'] = "octaron82@gmail.com"
msg['To'] = destinatario
msg['Subject'] = "Prueba de envío automático"

# Agregando el mensaje en el cuerpo del correo:
msg.attach(MIMEText(mensaje, 'plain'))

#Indicando el servidor y el puerto:
server = smtplib.SMTP('smtp.gmail.com: 587')

server.starttls()

# Ingresando credenciales para enviar el correo
server.login(msg['From'], password)

# Enviando el mensaje a través del "server".
server.sendmail(msg['From'], msg['To'], msg.as_string())

server.quit()

#print "successfully sent email to %s:" % (msg['To'])
print('Ya acabó')
